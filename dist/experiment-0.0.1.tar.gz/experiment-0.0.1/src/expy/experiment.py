import numpy as np
import os 

#local import
from .event import Event


#should it be a dictionary i.e. a dictionary of events each event has a name 
class Experiment(dict):

	def __init__(self, name = ""):
		super().__init__()
		self.name = name
		

	def summary(self):
		print(f"Experiment: {self.name} \n{len(self)} events found")

	def load_data(self, files, folder = True, extension = ""):
		"""
		Create events for each file.

		Input
		-----------------------------------------------------------------
		files: str or list
			file or folder names. It can be a list of filenames
		folder: bool, default = True 
			if True the string will be consider as a folder, otherwise as a file 
		extension: str, default = ""
			can specify the file extension when files is a folder name 

		"""
		if(folder):
			#lists files if a folder is given instead of a list of files
			files = files +"/" if not files.endswith("/") else files 
			files = [files + f for f in os.listdir(files) if f.endswith(extension)]
		else:
			#if a single file name is given then make it a list 
			if(isinstance(files, str)):
				files = [files]


		for f in files:
			#strip the file name and create an event with the name 
			ev = Event(f)
			self[ev.name] = ev



if __name__ == '__main__':
	ex = Experiment("ciccio")
	folder = "../../tests/"
	file = "Spot1_G_P00.dat"
	ex.load_data(folder+file,folder = False)
	ex.summary()
	
