import numpy as np
import pandas as pd 

import scimate.mathtools as mt

def tokenize(string, char = "_"):
    """
    Split the file name in individual tokens that can have important information 
    a special tocken is Pid that is given by a tocken starting with P and followed by a namber 

    Input
    -----------------------------------------------
    string:str
        Input string to tokenize
    char: str
        Character used to split

    Output
    -----------------------------------------------
    dict
        Dictionary of the tokens

    """
    s = string.split(char)
    tokens = {}
    count = 0
    for i in s:
        if(i.startswith("P") and not ("Pid" in tokens)):
            tokens["Pid"] = i
        else:
            tokens[f"T{count + 1}"] = i
            count +=1
    return tokens




 
class Event:
    """
    Event class gathering in a dictionary the data and fit results
    """
    def __init__(self, data = None,tokenby = "_"):
        """
        Input
        -----------------------------------------------------------------
        data: str or DataFrame
            if str it should be a file name of data without header. Else self.data will be assigned to the DataFrame
        tokenby: str , default is "_"
            character used by tokenize
        """
        if(isinstance(data,str)):
            self.get_data(data)
            #remove file folder path and file type
            self.name = data.split("/")[-1].split(".")[0]
            self.tokens = tokenize(self.name)
        else:
            self.data = data

        # if(data is not None): self.normalize(self.data)


    def set_P(self):
        pass

    def set_position(self):
        pass

    def normalize(self,ref):
        mt.normalize(self.data,ref)



    def get_data(self,filename,header = "Fityk"):
        """
        Read a file containing data in columns. A header can be specified.
        
        Input
        -----------------------------------------------------------------
        filename: str
            Input file
        header: 
            Build header in "Fityk" format or as pandas.read_table 

        """

        #read the data file. Except the case in which the header tipe is wrong. "Fityk" also falls in this case 
        try:
            df = pd.read_table(filename,header = header,sep = " ")

        except ValueError:

            df = pd.read_table(filename,header = None,sep = " ")
            if(header == "Fityk"):
                   df.columns = ["x","y"] + [f"f{i}" for i in range(df.columns.size - 3)] + ["ftot"]
            else:
                print("Wrong header format. None is considered.")
        self.data = df

    def read_fityk(self,filename, errors = True):
        """
        Reads a .peak fityk file and adds it to event as "fit"

        Input
        -----------------------------------------------
        filename:str
            file containg the fit results
        errors:bool
            read or not the parameters error
        Returns
        -----------------------------------------------
        pandas.DataFrame:
            DataFrame containing the functions identidier, name and parameters  


        """
        #x is used for the quantities that do not have clearly defined one of the standard parameters (Center,Height...). They will be replaced by NaN
        df = pd.read_table(filename,na_values = "x")

        #split function name and id 
        df["fid"] = [x.split()[0] for x in df.loc[:,"# PeakType"]]
        df["fname"] = [x.split()[1] for x in df.loc[:,"# PeakType"]]

        #split the parameters that are placed all together by Fityk and replace ? by 0 for unknown errors 
        pars = pd.DataFrame([map(float,x.replace("+/-","").replace("?","0").split()) for x in df.loc[:,"parameters..."]])
        if(errors):
            pars.columns = [f"a{int(i/2)}" if (not i%2) else f"err_a{int(i/2)}" for i in range(len(pars.columns))]
        else:
            pars.columns = [f"a{i}" for i in range(len(pars.columns))]

        #adds the parameters 
        df = df.join(pars)

        #drop useless columns 
        df.drop(columns = ["# PeakType",'parameters...'],inplace = True)

        #reorder the dataframe
        first = ["fid","fname"]
        [df.insert(i,x.name,x) for i,x in enumerate([df.pop(y) for y in first])]


        #add the functions dataframe and calculates the 
        self.function = df








if __name__ == '__main__':
    filename = '../../tests/Spot1_G_P00.dat'
    filename2 = '../../tests/Spot1_G_P00.peaks'
    ev = Event(filename)
    ev.read_fityk(filename2)
    print(ev.function)